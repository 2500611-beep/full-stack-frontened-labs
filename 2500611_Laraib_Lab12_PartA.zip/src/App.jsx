// Name: Laraib
// Reg No: 2500611

import React, { useState, useEffect, useMemo } from 'react';
import Counter from './components/Counter';
import UserCard from './components/UserCard';

function App() {
  const [users, setUsers] = useState([]);
  const [search, setSearch] = useState('');
  const [favs, setFavs] = useState([]);
  // Task 3: Show only favourites checkbox state
  const [onlyFavs, setOnlyFavs] = useState(false);

  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/users')
      .then((res) => res.json())
      .then((data) => setUsers(data))
      .catch(() => {
        setUsers([
          {
            id: 1,
            name: 'Leanne Graham',
            email: 'Sincere@april.biz',
            address: { street: 'Kulas Light', city: 'Gwenborough' },
            company: { name: 'Romaguera-Crona' },
          },
          {
            id: 2,
            name: 'Ervin Howell',
            email: 'Shanna@melissa.tv',
            address: { street: 'Victor Plains', city: 'Wisokyburgh' },
            company: { name: 'Deckow-Crist' },
          },
        ]);
      });
  }, []);

  const toggleFav = (id) => {
    setFavs((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  // Task 3: Filter by search AND onlyFavs
  const visible = useMemo(() => {
    return users.filter((u) => {
      const matchesSearch = u.name.toLowerCase().includes(search.toLowerCase());
      const matchesFav = !onlyFavs || favs.includes(u.id);
      return matchesSearch && matchesFav;
    });
  }, [users, search, onlyFavs, favs]);

  return (
    <div style={{ maxWidth: '900px', margin: '0 auto', padding: '24px', fontFamily: 'sans-serif' }}>
      <h1>User Directory (Lab 12 Part A)</h1>
      <Counter />

      <div style={{ display: 'flex', gap: '16px', alignItems: 'center', marginBottom: '16px' }}>
        <input
          type="text"
          placeholder="Search users..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{ padding: '8px', width: '250px' }}
        />

        <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer' }}>
          <input
            type="checkbox"
            checked={onlyFavs}
            onChange={(e) => setOnlyFavs(e.target.checked)}
          />
          Show only favourites
        </label>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: '14px' }}>
        {visible.map((user) => (
          <UserCard
            key={user.id}
            user={user}
            isFav={favs.includes(user.id)}
            onToggleFav={toggleFav}
          />
        ))}
      </div>
    </div>
  );
}

export default App;
