// Name: Laraib
// Reg No: 2500611

import React from 'react';

function Button({ children, onClick, active = false }) {
  return (
    <button
      onClick={onClick}
      style={{
        padding: '6px 12px',
        marginRight: '6px',
        borderRadius: '6px',
        border: '1px solid #2563eb',
        backgroundColor: active ? '#2563eb' : '#ffffff',
        color: active ? '#ffffff' : '#2563eb',
        cursor: 'pointer',
        fontWeight: '500',
      }}
    >
      {children}
    </button>
  );
}

export default Button;
