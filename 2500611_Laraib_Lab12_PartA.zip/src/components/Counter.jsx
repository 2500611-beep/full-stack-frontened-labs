// Name: Laraib
// Reg No: 2500611

import React, { useState } from 'react';
import Button from './Button';

// Task 1: Counter with step state (1, 5, 10) and "+" / "-" buttons
function Counter() {
  const [count, setCount] = useState(0);
  const [step, setStep] = useState(1);

  return (
    <div
      style={{
        padding: '16px',
        border: '1px solid #d1d5db',
        borderRadius: '8px',
        marginBottom: '20px',
        backgroundColor: '#f9fafb',
      }}
    >
      <h2 style={{ marginBottom: '10px' }}>Counter: {count} (Step: {step})</h2>

      {/* Step selector buttons */}
      <div style={{ marginBottom: '10px' }}>
        <Button active={step === 1} onClick={() => setStep(1)}>Step 1</Button>
        <Button active={step === 5} onClick={() => setStep(5)}>Step 5</Button>
        <Button active={step === 10} onClick={() => setStep(10)}>Step 10</Button>
      </div>

      {/* Increment and Decrement by step */}
      <div>
        <Button onClick={() => setCount((c) => c + step)}>+</Button>
        <Button onClick={() => setCount((c) => c - step)}>-</Button>
      </div>
    </div>
  );
}

export default Counter;
