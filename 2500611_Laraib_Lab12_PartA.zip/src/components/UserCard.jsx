// Name: Laraib
// Reg No: 2500611

import React from 'react';
import Button from './Button';

// Task 2: Destructure address and company; display street, city, and company in bold
function UserCard({ user, isFav, onToggleFav }) {
  const { address, company } = user;

  return (
    <div
      style={{
        border: '1px solid #d1d5db',
        borderRadius: '8px',
        padding: '14px',
        backgroundColor: '#ffffff',
      }}
    >
      <h3>{user.name}</h3>
      <p style={{ color: '#4b5563', fontSize: '14px' }}>{user.email}</p>
      <p style={{ marginTop: '6px', fontSize: '14px' }}>
        Address: {address.street}, {address.city}
      </p>
      <p style={{ marginTop: '4px', fontSize: '14px' }}>
        Company: <strong>{company.name}</strong>
      </p>
      <div style={{ marginTop: '10px' }}>
        <Button active={isFav} onClick={() => onToggleFav(user.id)}>
          {isFav ? 'Unfavourite' : 'Favourite'}
        </Button>
      </div>
    </div>
  );
}

export default UserCard;
